var { TelegramClient, Api } = require('telegram');
var { StringSession, StoreSession } = require('telegram/sessions');
var fs = require('fs');
var info = { numero: '', idBot: '', apiId: 7165779, apiHash: 'b5ec1fb9cd2d99f2361294b06bbd2983' };
var color = require('chalk');


class telefone{

	constructor(){
		this.tel = 'xxx'
	}

	inputTel(value){
		this.tel = value;
		return this;
	}

	async consultar(){
		var promise = async()=> await new Promise(async(resolve,reject)=>{
		try{

		var sessionId = JSON.parse(fs.readFileSync('./sessão/sessão.json')) 
		const sessão = new StringSession(sessionId); //string com dados da sessão
		const client = new TelegramClient(sessão, info.apiId, info.apiHash, { connectionRetries: 5 })
		console.log('[ CARREGANDO TELEGRAM ]')
		await client.start({ 
			phoneNumber: info.numero, 
			onError: (err) => console.log(err), 
		})
		console.log('[ CONECTADO COM SUCESSO ]')
		await fs.writeFileSync(`./sessão/sessão.json`, await JSON.stringify(client.session.save(),null)) //salvar dados da sessão
		var infoMe = await client.invoke(new Api.messages.SendMessage({ peer: 'me', message: 'request info' }))
		var requestMessageCpf = await client.invoke(new Api.messages.SendMessage({ peer: 'consultas_on', message: `/telefone ${this.tel}` }))
		client.addEventHandler(async(msg) => {
		if(msg.className == 'UpdateNewChannelMessage'){
			var objectMsg = {
				mensagem: msg.message.message,
				idGrupo: msg.message._chatPeer.channelId,
				usuario: msg.message._senderId,
				myId: infoMe.users[0].id,
				idMsg: msg.message.id
			}
			if(JSON.stringify(msg).includes('replyToMsgId')){
			if(msg.message.replyTo.replyToMsgId == requestMessageCpf.updates[0].id){
				if(JSON.stringify(msg).includes(this.tel)){
				var pushMyName = []
				if(infoMe.users[0].lastName == '' || infoMe.users[0].lastName == undefined){ pushMyName = infoMe.users[0].firstName } else { pushMyName = `${infoMe.users[0].firstName} ${infoMe.users[0].lastName}` }
				var replaceParam = objectMsg.mensagem
				.replace('Skynet02Robot', '{BOT}')
				.replace('• USUÁRIO: Dr Stone', '• USUÁRIO: {USUARIO}')
				.replace('"', '')
				.replace('"', '')
				console.log(objectMsg.mensagem)
				return resolve(replaceParam)
				} else {
				console.log('[ ELSE ]')
				var replaceParam2 = objectMsg.mensagem
				.replace('Skynet02Robot', '{BOT}')
				.replace('ArcadianRobot', '{BOT}')
				.replace('• USUÁRIO: Dr Stone', '• USUÁRIO: {USUARIO}')
				.replace('USUÁRIO: Dr', 'USUÁRIO: {USUARIO}')
				.replace('"', '')
				.replace('"', '')
				console.log(replaceParam2)
				return resolve(replaceParam2)
			}
		}
	}
}
})
}catch(e){ resolve('*Aguarde '+regexNumeros(e.message)+' segundos para realizar uma nova consulta!*')}
})
return promise()
}
};




function regexNumeros(num) {
	return num.replace(/[^0-9]|[-.]/g, "");
}

module.exports = {
	telefone
}