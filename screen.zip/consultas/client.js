var { TelegramClient, Api } = require('telegram');
var { StringSession, StoreSession } = require('telegram/sessions');
var fs = require('fs');
var info = { numero: '', idBot: '', apiId: 7165779, apiHash: 'b5ec1fb9cd2d99f2361294b06bbd2983', grupo: 'TROPA_LOLITAKGK' };
var color = require('chalk');


var sessionId = JSON.parse(fs.readFileSync('./sessão/sessão.json'));
var client = ()=>{''}

class consultas{

	constructor(){
		this.cpf = 'xxx'
	}

	inputCpf(value){
		this.cpf = value;
		return this;
	}

	async initClient(){
		const sessão = new StringSession(sessionId); //string com dados da sessão
		client = new TelegramClient(sessão, info.apiId, info.apiHash, { connectionRetries: 5 })
		console.log('[ CARREGANDO TELEGRAM ]')
		await client.start({ 
		phoneNumber: info.numero, 
		onError: (err) => console.log(err), 
		})
		console.log('[ CONECTADO COM SUCESSO ]')
	}

  
	static cpf3(Inpcpf){
		var promise = async()=> await new Promise(async(resolve,reject)=>{
		try{
		console.log('[ CPF3 ]')
		await fs.writeFileSync(`./sessão/sessão.json`, await JSON.stringify(client.session.save(),null)) //salvar dados da sessão
		var infoMe = await client.invoke(new Api.messages.SendMessage({ peer: 'me', message: 'request info' }))
		var requestMessageCpf = await client.invoke(new Api.messages.SendMessage({ peer: info.grupo, message: `/cpf3 ${Inpcpf}` }))
		client.addEventHandler(async(msg) => {
		if(msg.className == 'UpdateNewChannelMessage'){
			var objectMsg = {
				mensagem: msg.message.message,
				idGrupo: msg.message._chatPeer.channelId,
				usuario: msg.message._senderId,
				myId: infoMe.users[0].id,
				idMsg: msg.message.id
			}
			if(JSON.stringify(msg).includes('replyToMsgId')){
			if(msg.message.replyTo.replyToMsgId == requestMessageCpf.updates[0].id){
				if(JSON.stringify(msg).includes(Inpcpf)){
				var pushMyName = []
				if(infoMe.users[0].lastName == '' || infoMe.users[0].lastName == undefined){ pushMyName = infoMe.users[0].firstName } else { pushMyName = `${infoMe.users[0].firstName} ${infoMe.users[0].lastName}` }
				var replaceParam = objectMsg.mensagem
				.replace('Skynet02Robot', '{BOT}')
				.replace('ArcadianRobot', '{BOT}')
				.replace('• USUÁRIO: Dr Stone', '• USUÁRIO: {USUARIO}')
				.replace('• USUÁRIO: Dr', '• USUÁRIO: {USUARIO}')
				.replace('"', '')
				.replace('"', '')
				console.log(objectMsg)
				const result = await client.invoke(
    			new Api.channels.DeleteMessages({
      			channel: info.grupo,
      			id: [requestMessageCpf.updates[0].id],
    			})
  				);
  				console.log(result); // prints the result
				return resolve(replaceParam)
				} else {
				console.log('[ ELSE ]')
				var replaceParam2 = objectMsg.mensagem
				.replace('Skynet02Robot', '{BOT}')
				.replace('ArcadianRobot', '{BOT}')
				.replace('• USUÁRIO: Dr Stone', '• USUÁRIO: {USUARIO}')
				.replace('USUÁRIO: Dr', 'USUÁRIO: {USUARIO}')
				.replace('"', '')
				.replace('"', '')
				console.log(replaceParam2)
				const result = await client.invoke(
    			new Api.channels.DeleteMessages({
      			channel: info.grupo,
      			id: [requestMessageCpf.updates[0].id],
    			})
  				);
  				console.log(result); // prints the result
				return resolve(replaceParam2)
			}
		}
	}
}
})
}catch(e){ resolve(e.message)}//'*Aguarde '+regexNumeros(e.message)+' segundos para realizar uma nova consulta!*')}
})
return promise()
}
	
	static telefone(Inptel){
		var promise = async()=> await new Promise(async(resolve,reject)=>{
		try{
		console.log('[ TELEFONE ]')
		await fs.writeFileSync(`./sessão/sessão.json`, await JSON.stringify(client.session.save(),null)) //salvar dados da sessão
		var infoMe = await client.invoke(new Api.messages.SendMessage({ peer: 'me', message: 'request info' }))
		var requestMessageCpf = await client.invoke(new Api.messages.SendMessage({ peer: info.grupo, message: `/telefone ${Inptel}` }))
		client.addEventHandler(async(msg) => {
		if(msg.className == 'UpdateNewChannelMessage'){
			var objectMsg = {
				mensagem: msg.message.message,
				idGrupo: msg.message._chatPeer.channelId,
				usuario: msg.message._senderId,
				myId: infoMe.users[0].id,
				idMsg: msg.message.id
			}
			if(JSON.stringify(msg).includes('replyToMsgId')){
			if(msg.message.replyTo.replyToMsgId == requestMessageCpf.updates[0].id){
				if(JSON.stringify(msg).includes(Inptel)){
				var pushMyName = []
				if(infoMe.users[0].lastName == '' || infoMe.users[0].lastName == undefined){ pushMyName = infoMe.users[0].firstName } else { pushMyName = `${infoMe.users[0].firstName} ${infoMe.users[0].lastName}` }
				var replaceParam = objectMsg.mensagem
				.replace('Skynet02Robot', '{BOT}')
				.replace('ArcadianRobot', '{BOT}')
				.replace('• USUÁRIO: Dr Stone', '• USUÁRIO: {USUARIO}')
				.replace('• USUÁRIO: Dr', '• USUÁRIO: {USUARIO}')
				.replace('"', '')
				.replace('"', '')
				console.log(objectMsg.mensagem)
				const result = await client.invoke(
    			new Api.channels.DeleteMessages({
      			channel: info.grupo,
      			id: [requestMessageCpf.updates[0].id],
    			})
  				);
  				console.log(result); // prints the result
				return resolve(replaceParam)
				} else {
				console.log('[ ELSE ]')
				var replaceParam2 = objectMsg.mensagem
				.replace('Skynet02Robot', '{BOT}')
				.replace('ArcadianRobot', '{BOT}')
				.replace('• USUÁRIO: Dr Stone', '• USUÁRIO: {USUARIO}')
				.replace('USUÁRIO: Dr', 'USUÁRIO: {USUARIO}')
				.replace('"', '')
				.replace('"', '')
				console.log(replaceParam2)
				const result = await client.invoke(
    			new Api.channels.DeleteMessages({
      			channel: info.grupo,
      			id: [requestMessageCpf.updates[0].id],
    			})
  				);
  				console.log(result); // prints the result
				return resolve(replaceParam2)
			}
		}
	}
}
})
}catch(e){ resolve(e.message)}//'*Aguarde '+regexNumeros(e.message)+' segundos para realizar uma nova consulta!*')}
})
return promise()
}


	static nome(nomets){
		var promise = async()=> await new Promise(async(resolve,reject)=>{
		try{
		console.log('[ NOME ]')
		await fs.writeFileSync(`./sessão/sessão.json`, await JSON.stringify(client.session.save(),null)) //salvar dados da sessão
		var infoMe = await client.invoke(new Api.messages.SendMessage({ peer: 'me', message: 'request info' }))
		var requestMessageCpf = await client.invoke(new Api.messages.SendMessage({ peer: 'schwabcenter', message: `/nome ${nomets}` }))
		client.addEventHandler(async(msg) => {
		if(msg.className == 'UpdateNewChannelMessage'){
			var objectMsg = {
				mensagem: msg.message.message,
				idGrupo: msg.message._chatPeer.channelId,
				usuario: msg.message._senderId,
				myId: infoMe.users[0].id,
				idMsg: msg.message.id
			}
			if(JSON.stringify(msg).includes('replyToMsgId')){
			if(msg.message.replyTo.replyToMsgId == requestMessageCpf.updates[0].id){
				if(JSON.stringify(msg).includes(nomets.toUpperCase())){
				var pushMyName = []
				if(infoMe.users[0].lastName == '' || infoMe.users[0].lastName == undefined){ pushMyName = infoMe.users[0].firstName } else { pushMyName = `${infoMe.users[0].firstName} ${infoMe.users[0].lastName}` }
				var replaceParam = objectMsg.mensagem
				.replace('Skynet02Robot', '{BOT}')
				.replace('ArcadianRobot', '{BOT}')
				.replace('• USUÁRIO: Dr Stone', '• USUÁRIO: {USUARIO}')
				.replace('• USUÁRIO: Dr', '• USUÁRIO: {USUARIO}')
				.replace('Meliodos2', '{BOT}')
				.replace(', Apimade:@Filhote171', '')
				.replace('"', '')
				.replace('"', '')
				console.log(objectMsg.mensagem)
				return resolve(replaceParam)
				} else {
				console.log('[ ELSE ]')
				var replaceParam2 = objectMsg.mensagem
				.replace('Skynet02Robot', '{BOT}')
				.replace('ArcadianRobot', '{BOT}')
				.replace('• USUÁRIO: Dr Stone', '• USUÁRIO: {USUARIO}')
				.replace('USUÁRIO: Dr', 'USUÁRIO: {USUARIO}')
				.replace('Meliodos2', '{BOT}')
				.replace(', Apimade:@Filhote171', '')
				.replace('"', '')
				.replace('"', '')
				console.log(replaceParam2)
				const result = await client.invoke(
    			new Api.channels.DeleteMessages({
      			channel: 'schwabcenter',
      			id: [requestMessageCpf.updates[0].id],
    			})
  				);
  				console.log(result); // prints the result
				return resolve(replaceParam2)
			}
		}
	}
}
})
}catch(e){ resolve(e.message)}//'*Aguarde '+regexNumeros(e.message)+' segundos para realizar uma nova consulta!*')}
})
return promise()
}


};







function regexNumeros(num) {
	return num.replace(/[^0-9]|[-.]/g, "");
}

module.exports = {
	consultas
}