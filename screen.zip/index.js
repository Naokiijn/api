const express = require('express');
const app = express();
const { consultas } = require('./consultas/client.js')
const { telefone } = require('./consultas/telefone.js')
const { nome } = require('./consultas/nome.js')
const { spawn, exec, execFile } = require('child_process')
new consultas().initClient()

async function screen(){
app.get('/cpf3/:doc', async (req, res) => {
res.setHeader('content-type', 'text/json');
var respcpf = await consultas.cpf3(req.params.doc)
console.log(respcpf)
await res.json({ res: respcpf })
//await exec('pm2 restart ./index.js')
})

app.get('/telefone/:doc', async (req, res) => {
var resptel = await consultas.telefone(req.params.doc)
console.log(resptel)
res.setHeader('content-type', 'text/json');
await res.json({ res: resptel })
//await exec('pm2 restart ./index.js') 
})

app.get('/nome/:doc', async (req, res) => {
var respnome = await consultas.nome(req.params.doc)
console.log(respnome)
res.setHeader('content-type', 'text/json');
await res.json({ res: respnome }) 
//await exec('pm2 restart ./index.js')
})

app.listen(8080)
}

screen()

